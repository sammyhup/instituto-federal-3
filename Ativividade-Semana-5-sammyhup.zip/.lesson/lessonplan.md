# Gabarito
![Grade](assets/F1-M3-Sem05-Praticas-Gabarito.png)

# Rubrica de correção
![Grade](assets/F1-M3-Sem05-Praticas-Grade.png)

  