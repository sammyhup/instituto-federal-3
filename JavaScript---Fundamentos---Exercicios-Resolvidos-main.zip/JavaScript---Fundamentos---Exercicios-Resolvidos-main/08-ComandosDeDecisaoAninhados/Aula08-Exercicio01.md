### EXERCÍCIOS (AULA 08 - COMANDOS DE DECISÃO ANINHADOS)
<hr>

1. Crie um algoritmo, utilizando a linguagem JavaScript, que leia dois números.

   Caso os dois números sejam positivos você deve testá-los para exibir as seguintes frases:
   *	Os dois números são pares;
   *	Os dois números são ímpares;
   *	Um par e um ímpar;

   Se existir pelo menos um número negativo ou igual a zero, exiba a frase informando: Existe pelo menos um número 0 ou negativo!