### EXERCÍCIOS (AULA 07 - COMANDOS DE DECISÃO)
<hr>

2. Usando o algoritmo do exercício anterior, altere o resultado para: Média <=3, "reprovado", Média < 6, "recuperação" e Média >=6, "aprovado".