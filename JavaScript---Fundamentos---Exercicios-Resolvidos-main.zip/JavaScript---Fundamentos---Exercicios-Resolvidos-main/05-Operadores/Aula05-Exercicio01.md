### EXERCÍCIOS (AULA 05 - OPERADORES)
<hr>
1. Elabore um algoritmo para testarmos a utilização dos operadores na linguagem JavaScript.

Considere as seguintes variáveis e seus respectivos valores:

```
a = 1;
b = 2;
c = 3;
d = "3";
e = false;
f = true;
```

Mostre na tela o resultado para as seguintes expressões:

```
a + b ** c - c % 2
b * (c / a - a)
(c == d) != e
(b >= a) == f
(c !== d) && (b % 1 == 0)
e || (b > c || f)
```