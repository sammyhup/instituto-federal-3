for (i = 7; i <= 1000; i++) {
  if (i % 7 == 3) {
    console.log(i);
  }
}