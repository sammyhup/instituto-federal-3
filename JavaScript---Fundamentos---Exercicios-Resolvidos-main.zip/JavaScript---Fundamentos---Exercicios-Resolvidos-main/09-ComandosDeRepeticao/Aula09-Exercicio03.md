
### EXERCÍCIOS (AULA 09 - COMANDOS DE REPETIÇÃO)
<hr>

3. Desenvolva um algoritmo que obtêm números do usuário e os soma. A cada repetição algoritmo deve perguntar ao usuário se o mesmo deseja continuar a digitar números. Enquanto o usuário digitar "s" o algoritmo continua a receber números e somá-los. Quando o usuário digita qualquer outra coisa o algoritmo termina e apresenta o valor da soma dos números.