
### EXERCÍCIOS (AULA 10 - COMANDOS DE REPETIÇÃO ANINHADOS)
<hr>

1.	Escreva um algoritmo que lê via teclado um número inteiro positivo e mostre na tela, como resultado, a quantidade de números primos existentes entre 1 e n.