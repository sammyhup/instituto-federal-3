Problema

Elabore um algoritmo para calcular o salário líquido de uma pessoa.
Solicite ao usuário que digite seu nome e o valor de seu salário bruto.
O imposto de renda a ser descontado é equivalente a 10% do salário bruto.
Ao final, mostre na tela o valor do salário líquido.

Versão: 06 - Entrada de Dados