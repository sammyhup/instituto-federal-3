/*
Palavras Chaves
Instruções
Blocos de Código
Comentários
*/

// Palavras chaves

// Instruções
console.log("Essa é a instrução 1") // Instrução 1
console.log("Essa é a instrução 2")

/* Blocos de código
   Vamos demonstrar abaixo várias instruções
*/
if (true) {
  console.log("Essa é a instrução 3")
  console.log("Essa é a instrução 4")
  console.log("Essa é a instrução 5")
}

// Comentários
