pais = "Brasil";
console.log("Exemplo de Saída");
produto = 5.86 * 82.41;
vendido = true;

