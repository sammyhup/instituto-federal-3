console.log("Monstrando de 1 até 10")
for (i = 1; i <= 10; i++) {
  console.log("i = ", i);
}
console.log("O programa finaliza aqui!");

