// comentário de uma linha

/* isto é um comentário longo
   de múltiplas linhas.
 */

