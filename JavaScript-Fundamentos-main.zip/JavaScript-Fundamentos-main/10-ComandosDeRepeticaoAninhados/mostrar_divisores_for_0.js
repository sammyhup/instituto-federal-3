console.log("Divisores do número 10: ")
for (var j = 1; j <= 10; j++) {
  if (10 % j == 0) {
    console.log(j)
  }
}

