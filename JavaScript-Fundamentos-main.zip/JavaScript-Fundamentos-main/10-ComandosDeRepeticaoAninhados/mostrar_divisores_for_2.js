for (var i = 1; i <= 10; i++) {
  console.log("Divisores do número", i, ":")
  for (var j = 1; j <= 10; j++) {
    if (i % j == 0) {
      console.log(j)
    }
  }
}

