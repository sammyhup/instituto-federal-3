function mostrar_mensagem() {
  console.log("Mensagem dentro da função");
}

