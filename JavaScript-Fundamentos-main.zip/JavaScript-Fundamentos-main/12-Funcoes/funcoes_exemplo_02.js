function calcular_produto(x, y, z) {
  console.log("Produto:", x*y*z);
}

calcular_produto(2, 3, 4);