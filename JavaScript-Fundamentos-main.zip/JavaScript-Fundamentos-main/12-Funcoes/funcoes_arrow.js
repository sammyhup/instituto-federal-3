// Expressão com arrow function
var q = (n) => n * n;
var resultado = q(4); // q recebe o valor 16
console.log(resultado);

// Expressão com arrow function
var s = (n1, n2) => n1 + n2;
resultado = s(3, 4);
console.log(resultado);


