function calcular_quociente(a, b) {
  return a / b;
}

resultado = calcular_quociente(11, 5);
console.log(resultado);