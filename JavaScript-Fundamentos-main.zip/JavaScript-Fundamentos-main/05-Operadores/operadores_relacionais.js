// Operadores relacionais (demonstração)
x = 10
y = 20
z = "10"

console.log("x =", x, " y =", y, " z =", z)
console.log("x == z:", x == z)
console.log("x != z:", x != z)
console.log("x === z:", x === z)
console.log("x !== z:", x !== z)
console.log("x < y", x < y)
console.log("x > y:", x > y)
console.log("x <= y:", x <= y)
console.log("x >= y:", x >= y)