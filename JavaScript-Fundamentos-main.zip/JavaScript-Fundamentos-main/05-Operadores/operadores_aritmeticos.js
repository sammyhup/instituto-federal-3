//Operadores aritméticos (demonstração)
x = 53
y = 24

soma = x + y            //Calculando	a soma
subtracao = x - y       //Calculando	a subtração
multiplicacao = x * y   //Calculando	a multiplicação
quociente = x / y       //Calculando	a divisão
resto = x % y           //Calculando	o módulo
potência = x ** y       //Calculando	a potência

console.log("x =", x, " y =", y)
console.log("Soma:", soma)
console.log("Subtração:", subtracao)
console.log("Multiplicação:", multiplicacao)
console.log("Quociente:", quociente)
console.log("Resto:", resto)
console.log("Potência:", potência)