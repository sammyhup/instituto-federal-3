// Operadores lógicos (demonstração) 
x = true
y = false

console.log("x =", x, " y =", y)
console.log("x || y:", x || y)
console.log("x && y:", x && y)
console.log("! x:", !x)

