var myArray = ['1', '2', '3'];
var ultimo = myArray.pop();
// myArray é agora ["1", "2"], ultimo = "3"

console.log(myArray);
console.log(ultimo);

