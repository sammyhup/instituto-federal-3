var myArray = ['a', 'b', 'a', 'b', 'a'];
console.log(myArray.indexOf('b'));    // mostra 1
console.log(myArray.indexOf('b', 2)); // mostra 3
console.log(myArray.indexOf('z'));   // mostra -1, não encontrado

