var myArray = ['1', '2', '3'];
var comp = myArray.unshift('4', '5');
// myArray torna-se ["4", "5", "1", "2", "3"]
// comp = 5

console.log(myArray);
console.log(comp);


