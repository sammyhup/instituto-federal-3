var myArray = ['1', '2'];
var comp = myArray.push('3');
// myArray é agora ["1", "2", "3"], comp = 3

console.log(myArray);
console.log(comp);

