var myArray = ['Neve', 'Chuva', 'Fogo'];
myArray.sort();
// myArray é agora [ "Chuva", "Fogo", "Neve" ]

console.log(myArray);

