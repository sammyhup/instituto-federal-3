// Iterando em um array

var cores = ['vermelho', 'verde', 'azul'];
for (var i = 0; i < cores.length; i++) {
  console.log(cores[i]);
}

