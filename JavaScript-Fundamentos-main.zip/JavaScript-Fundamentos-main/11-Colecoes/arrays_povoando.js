// Criando e povoando um array

var emp = ['João', 'Maria', 'Augusto'];
console.log(emp);

var emp = [];
emp[0] = 13;
emp[1] = 50;
emp[2] = 72;
console.log(emp);

