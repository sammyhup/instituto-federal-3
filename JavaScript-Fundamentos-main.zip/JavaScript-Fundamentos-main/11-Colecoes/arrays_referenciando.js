// Referenciando elementos em array

var myArray = ['Vento', 'Chuva', 'Fogo'];
console.log(myArray[0]);
console.log(myArray[1]);
console.log(myArray[2]);

