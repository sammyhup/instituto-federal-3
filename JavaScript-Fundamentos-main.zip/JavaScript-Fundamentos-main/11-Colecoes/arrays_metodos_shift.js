var myArray = ['1', '2', '3'];
var primeiro = myArray.shift();
// myArray agora é ["2", "3"], primeiro é "1"

console.log(myArray);
console.log(primeiro);

