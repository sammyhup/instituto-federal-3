// Demonstração do laço 'while'

i = 1 // Inicializa a variável com 1

while (i <= 10) { // Laço de 1 até 10
  console.log(i * 3) // Imprime i x 3
  i++ // Incrementa a variável i
}



