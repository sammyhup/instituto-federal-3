// Demonstração do laço 'for'

for (i = 1; i <= 10; i++) { // Laço de 1 até 10
  console.log(i * 3) // Imprime i x 3
}



