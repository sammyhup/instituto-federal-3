// Demonstração do 'break'

cont = 1 // Inicializa cont com 1

while (cont <= 10) { // Laço de 1 até 10
  // Checa se cont é 5
  if (cont == 5) {
    // Sai do laço se cont for 5
    break
  }
  console.log(cont) // Imprime cont
  cont++ // Incrementa cont
}

