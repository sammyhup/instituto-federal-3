// Demonstração (sem converter tipos de dados)

const prompt = require('prompt-sync')();

x = prompt("Digite o número 1: ")
y = prompt("Digite o número 2: ")

// Somando as duas variáveis strings
soma = x + y

console.log("\nx =", x, "\ny =", y)
console.log("\nsoma =", soma)

