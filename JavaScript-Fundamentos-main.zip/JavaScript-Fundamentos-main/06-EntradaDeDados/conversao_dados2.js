// Demonstração (convertendo tipos de dados)

const prompt = require('prompt-sync')();

x = parseInt(prompt("Digite o número 1: "))
y = parseInt(prompt("Digite o número 2: "))

// Somando as duas variáveis inteiras
soma = x + y

console.log("\nx =", x, "\ny =", y)
console.log("\nsoma =", soma)

