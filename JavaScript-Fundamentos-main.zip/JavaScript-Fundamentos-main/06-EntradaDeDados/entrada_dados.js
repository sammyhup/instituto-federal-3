// Demonstração de entrada de dados do usuário

const prompt = require('prompt-sync')();

nome = prompt("Entre com seu nome: ");
idade = prompt("Entre com sua idade: ");
endereco = prompt("Entre com seu endereço: ");

console.log("Nome: ", nome);
console.log("Idade: ", idade);
console.log("Endereço: ", endereco);

