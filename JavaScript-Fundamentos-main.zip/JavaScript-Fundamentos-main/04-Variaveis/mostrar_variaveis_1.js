// Mostrando conteúdo de variáveis

num = 1654
item = "Impressora"
console.log(num)
console.log(item)

pc = "Dell 15 3000"
custo = 4030.87
console.log(pc, custo)

