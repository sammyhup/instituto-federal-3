// Demonstração de variáveis

nome = "Vanessa";
idade = 17;
altura = 1.65;

