// Mostrando conteúdo de variáveis

nome = "Maria"
idade = 31
console.log("Nome:", nome, "Idade:", idade)

