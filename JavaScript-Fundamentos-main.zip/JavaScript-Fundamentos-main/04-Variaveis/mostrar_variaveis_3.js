// Mostrando conteúdo de variáveis

a = 4
b = 6.4
nome = "José"
idade = 32
profissao = "Professor"
console.log("a =", a)
console.log("b =", b)
console.log("\n\nNome =", nome, "\nIdade =", idade, "\nProfissão =", profissao)

