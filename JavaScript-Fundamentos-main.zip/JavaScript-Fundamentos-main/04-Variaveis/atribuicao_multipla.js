// Demonstração de atribuição múltiplipa
// a, b, c e d receberão o valor numérico de 100.
a = b = c = d = 100
console.log(a)
console.log(d)

