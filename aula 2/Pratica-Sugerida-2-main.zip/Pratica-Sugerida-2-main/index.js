console.log("Linha 1");
console.log("Linha 2");
console.log("Essa era para ser a linha 3");
console.log("Linha 4");
console.log("Linha 5");
console.log("teste1");
console.log("aaaa");

//Teste de 02 usuários simultâneos