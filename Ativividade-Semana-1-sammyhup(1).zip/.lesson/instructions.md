# Prática da Semana 1
  
Elabore um algoritmo que receba três números e ao final imprima na tela, a soma dos três números e a média dos três números.

  ## Exemplo de execução do programa
  
  ![Exemplo](assets/F1-M3-Sem01-Praticas-Exemplo.png)

  ## Grade de correção
  ![Grade](assets/F1-M3-Sem01-Praticas-Grade.png)

  ## Objetivos de aprendizagem
  1. Declarar variáveis
  2. Utilizar operadores
  3. Utilizar comandos de entrada e saída de dados
  

  