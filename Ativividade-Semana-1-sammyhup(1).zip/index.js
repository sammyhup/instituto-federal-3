const prompt = require("prompt-sync")();
nome = prompt ( "Entre com seu nome: ");
// Leia os três números
numero1 = prompt ( "Digite um numero ");
numero2 = prompt("Digite o número 2:");
numero3 = prompt("Digite o número 3:");

numero1 = parseInt (numero1);
numero2 = parseInt (numero2);
numero3 = parseInt (numero3);
// Calcule a soma e a média
var soma = (numero1 + numero2 + numero3);
var media = soma/3;
// Mostre na tela o valor da soma e média
console.log("A soma dos seus numeros são: ", soma, "e a média dos seus numeros foi: ", media );