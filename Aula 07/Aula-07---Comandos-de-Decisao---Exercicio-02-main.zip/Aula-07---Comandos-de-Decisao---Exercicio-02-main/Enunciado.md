EXERCÍCIOS (AULA 07 - COMANDOS DE DECISÃO)

1. Crie um algoritmo que receba pelo teclado o nome de um aluno e três notas. Ao final,
deverá ser exibido o nome do aluno, sua média e o resultado (se for acima ou igual a 6, o
aluno estará “aprovado”; se não for, estará “reprovado”).
2. Usando o algoritmo do exercício anterior, altere o resultado para: Média <=3, “reprovado”,
Média < 6, “recuperação” e Média >=6, “aprovado”.

NESSE REPOSITÓRIO, VAMOS RESOLVER A ATIVIDADE 02