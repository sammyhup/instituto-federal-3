Crie um algoritmo em que, dada a tabela a seguir, calcula e exibe na tela o valor de
desconto a ser concedido para um determinado cliente, de acordo com o valor da compra.
O algoritmo deverá receber pelo teclado o nome do cliente e o valor total da compra.

TABELA:

Abaixo de R$ 1.000,00 - % de desconto: 5
Entre R$ 1.000,00 a R$ 5.000,00 - % de desconto: 10
Acima de R$ 5.000,00 - % de desconto: 15