const prompt = require('prompt-sync')();

idade = parseInt(prompt("Digite sua idade: "));
tempo = parseInt(prompt("Digite seu tempo de serviço: "));
salario = parseFloat(prompt("Digite seu salário R$: "));

// Implementar o comando de decisão para verificar se o cidadão pode, ou não, se aposentar
if (idade >= 65 || tempo >= 30 || (idade >= 60 && tempo >= 25)) {
  console.log("Você pode se aposentar!");
  if (tempo > 20) {
    // Implementar os comandos de decisão aninhados para calcular o salário de aposentadoria (80% ou 60%)
    var aposentadoria = salario * 0.80
    if (aposentadoria < 1212.00) {
      aposentadoria = 1212.00
    }
      // Implementar os comandos de decisão aninhados para garantir o salário de aposentadoria dentro dos limites inferior (R$ 1212,00) e superior (R$ 7087,22)
    else if (aposentadoria > 7087.22) {
      aposentadoria = 7087.22
    }
    console.log("Seu salário de aposentado será de: R$", aposentadoria);
  }

  else if (tempo <= 20) {
    var aposentadoria = salario * 0.60
    if (aposentadoria < 1212.00) {
      aposentadoria = 1212.00
    }
    else if (aposentadoria > 7087.22) {
      aposentadoria = 7087.22
    }
    console.log("Seu salário de aposentado será de: R$", aposentadoria);
  }
}

else {
  console.log("Você não pode se aposentar");
}





