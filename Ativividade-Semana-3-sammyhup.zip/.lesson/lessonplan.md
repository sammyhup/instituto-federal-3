# Gabarito
![Grade](assets/F1-M3-Sem03-Praticas-Gabarito.png)

# Rubrica de correção
![Grade](assets/F1-M3-Sem03-Praticas-Grade.png)