var n1 = 10;
var n2 = 20;
console.log("Linha 1");
console.log("Linha 2");
console.log("Linha 3");
console.log("Linha 4");
console.log("Linha 5");
n1 = 100;
n2 = 200;
console.log('n1: ', n1);
console.log('n2: ', n2);

//Aprendizado sobre breakpoints