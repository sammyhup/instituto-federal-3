Crie um algoritmo que receba pelo teclado o nome de um aluno e três notas. Ao final,
deverá ser exibido o nome do aluno, sua média e o resultado (se for acima ou igual a 6, o
aluno estará “aprovado”; se não for, estará “reprovado”).

